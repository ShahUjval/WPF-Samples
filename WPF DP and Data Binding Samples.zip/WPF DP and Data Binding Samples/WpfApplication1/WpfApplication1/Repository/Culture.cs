﻿namespace WpfApplication1.Repository
{
    public  class Culture
    {
        public string Lang { get; set; }
        public string Region { get; set; }
    }
}
